let user = 0;
let comp = 0;

let choices = document.querySelectorAll(".choice");
let display = document.querySelector("#msg");
let user_score = document.querySelector('#user_score');
let comp_score = document.querySelector('#comp_score');

function random_choice() {
  let arr = ["rock", "paper", "scissor"];
  let randidx = Math.floor(Math.random() * 3);
  return arr[randidx];
}

function draw_match() {
    console.log("Match is draw");
}

function result(user_win){
    if (user_win) {
        user++;
        user_score.innerText = user;
        console.log("User Win");
        display.innerHTML="User Win";
        display.style.backgroundColor ="Green";
      } else {
        comp++;
        comp_score.innerText = comp;
        console.log("Computer Win");
        display.innerHTML="Computer Win";
        display.style.backgroundColor ="Red";
        
      }
}

function playgame(user_choice) {
  console.log("User choice = ", user_choice);
  let comp_choice = random_choice();
  console.log("Computer Choice =", comp_choice);

  if (user_choice === comp_choice) {
    draw_match();
    display.innerHTML="Match is draw";
    display.style.backgroundColor ="darkblue";
  } else {
    let user_win = true;
    if (user_choice === "rock") {
      user_win = comp_choice === "paper" ? false : true;
    } else if (user_choice === "paper") {
      user_win = comp_choice === "scissor" ? false : true;
    } else if (user_choice === "scissor") {
      user_win = comp_choice === "rock" ? false : true;
    }
    result(user_win);
  }

}

choices.forEach((choice) => {
  choice.addEventListener("click", () => {
    const user_choice = choice.getAttribute("id");
    console.log("Choice was clicked", user_choice);
    playgame(user_choice);
  });
});
